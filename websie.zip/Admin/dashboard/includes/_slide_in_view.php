<div class="offcanvas offcanvas-end" data-bs-scroll="true" data-bs-backdrop="false" tabindex="-1" id="description_modal"
    aria-labelledby="offcanvasScrollLabel">
    <div class="offcanvas-header">
        <h5 id="offcanvasScrollLabel" class="offcanvas-title the_title"></h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body my-auto mx-0 flex-grow-0">
        <p class="text-center the_description">
            
        </p>
        <!-- <button type="button" class="btn btn-primary mb-2 d-grid w-100">Continue</button> -->
        <button type="button" class="btn btn-outline-secondary d-grid w-100" data-bs-dismiss="offcanvas">
            Close
        </button>
    </div>
</div>